package com.jbk.Alpha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlphaApplicationTests {

	@Test
	void contextLoads() {
	}

}
