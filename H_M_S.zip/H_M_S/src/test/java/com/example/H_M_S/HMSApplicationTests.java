package com.example.H_M_S;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HMSApplicationTests {

	@Test
	void contextLoads() {
	}

}
