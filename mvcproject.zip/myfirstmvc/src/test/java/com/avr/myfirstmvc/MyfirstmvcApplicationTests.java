package com.avr.myfirstmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyfirstmvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
