package com.jbk.thekiranacademy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtifactApplicationTests {

	@Test
	void contextLoads() {
	}

}
