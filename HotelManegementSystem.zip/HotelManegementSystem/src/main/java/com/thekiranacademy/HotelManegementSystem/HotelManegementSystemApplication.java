package com.thekiranacademy.HotelManegementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelManegementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelManegementSystemApplication.class, args);
	}

}
