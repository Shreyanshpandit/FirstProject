package com.tka.Vishay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VishayApplicationTests {

	@Test
	void contextLoads() {
	}

}
