package com.tka.Vishay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VishayApplication {

	public static void main(String[] args) {
		SpringApplication.run(VishayApplication.class, args);
	}

}
