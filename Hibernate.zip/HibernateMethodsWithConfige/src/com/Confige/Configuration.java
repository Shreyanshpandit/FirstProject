package com.Confige;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.Entity.Emp;

import org.hibernate.SessionFactory;
import com.Entity.Emp;

public class Configuration {
	
	public static SessionFactory getConfige() {
	org.hibernate.cfg.Configuration cfg = new org.hibernate.cfg.Configuration();
	cfg.configure();
	cfg.addAnnotatedClass(Emp.class);
	
	SessionFactory sf = cfg.buildSessionFactory();
	
	return sf;
}
}