package com.Dao;

import com.Confige.Configuration;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.Entity.Emp;

public class EmpDao {
	private SessionFactory sf = Configuration.getConfige();

	public Emp getEmp() {
		Session Session = sf.openSession();
		Emp Emp = Session.load(Emp.class, 1);
		
		return Emp;
		
	}

	
}
