package com.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Emp {
	private int eid;
	private String ename;
	
	@Id
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	@Override
	public String toString() {
		return "EmployeeDao [eid=" + eid + ", ename=" + ename + "]";
	}
	
	

}
