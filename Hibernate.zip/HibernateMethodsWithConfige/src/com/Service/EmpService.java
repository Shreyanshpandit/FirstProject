package com.Service;

import com.Dao.EmpDao;
import com.Entity.Emp;

public class EmpService {

		public Emp getEmp() {
			EmpDao ed = new EmpDao();
			Emp Emp = ed.getEmp();
			
			return Emp;
		}

}
