package com.Controller;

import com.Entity.Emp;
import com.Service.EmpService;

public class EmpController {

		public void getEmp() {
			EmpService es = new EmpService();
			Emp Emp = es.getEmp();
			
			System.out.println(Emp);
		}
		public static void main(String[] args) {
			EmpController ec = new EmpController();
			ec.getEmp();
		}
		
}
