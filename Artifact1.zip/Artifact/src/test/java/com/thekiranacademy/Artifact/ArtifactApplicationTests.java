package com.thekiranacademy.Artifact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtifactApplicationTests {

	@Test
	void contextLoads() {
	}

}
